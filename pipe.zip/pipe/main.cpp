#include "dict.hpp"

int main(int argc, char* argv[])
{
    cout << "Entre with dictionary 1" << endl;
    //check system inputs
    string dictstr1;
    cin >> dictstr1;
    vector<string> list1 = LoadDictionary(dictstr1.c_str());
    if(list1.size() == 0)
    {
        cout << "Error, file not found" << endl;
        return 2;
    }

    cout << "Entre with dictionary 1" << endl;
    string dictstr2;
    cin >> dictstr2;
    vector<string> list2 = LoadDictionary(dictstr2.c_str());
    if(list2.size() == 0)
    {
        cout << "Error, file not found" << endl;
        return 2;
    }
   
    //concatena
    for(size_t i = 0;i < list2.size();i++){
        list1.push_back(list2.at());
    }
    list2.clear();
    for(size_t i = 0;i < list1.size();i++)
    {
       // LoadDictionary(list1.c_str());
    }

    cout << "Entre a min num of character to remove" << endl;
    unsigned int wordSize = 0;
    cin >> wordSize;
    
    //Eliminar duplicatas
    vector<string> Wordlist = list1;
    sort (Wordlist.begin(), Wordlist.begin()+4);

/*
    size_t numberofWords;
    cin >> numberofWords;
    for(size_t i=0; i<numberofWords; i++)
    {
        //searching a word in our dictionary
        bool success = false;
        string query;
        cin >> query;
        
        //how many words do we have as substrings ?
        size_t counter=0;        
        for(size_t i=0; i< list.size(); i++)
        {
            size_t pos = list.at(i).find(query);
            if(pos < list.at(i).length())
            {
                counter++;
                cout << list.at(i) << endl;
            }
        }
        cout << "Total of " << query << "-" << counter << endl;
        cout << endl;
    }
    */
    return 0;
}
